function [ ret ] = aveNeighborDeg( A )
%aveNeighborDeg Alias of averageNeighborDegree
%   See averageNeighborDegree for info.
ret = averageNeighborDegree(A);

end

