function d=linkDensity(A)
%LINKDENSITY Computes the edge density of a graph.
% Aliased from edgeDensity. See edgeDensity for documentation.

[ d ] = edgeDensity( A );