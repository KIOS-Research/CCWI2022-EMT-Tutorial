function [ l, path_lengths ] = avePathLength( A )
%AVEPATHLENGTH An alias of averagePathLength
%   See averagePathLength for more information.
[l, path_lengths]  = averagePathLength(A);

end

